DOWNLOADED CONTENT IS FOR PERSONAL USE ONLY.

Included artwork may not be modified, reused, remixed or distributed. Copyright 2024 Larry Seyer.

---------------------

Reaper forum thread: https://forum.cockos.com/showthread.php?t=248364

---------------------

READ THE INSTALL GUIDE and/or WATCH THE FOLLOWING VIDEO!

How to install video:

https://www.youtube.com/watch?v=zNmh2zTb1f4

---------------------

* DOWNLOAD FULL FREE installation package (recommended), please visit: https://larryseyer.com/icandy

